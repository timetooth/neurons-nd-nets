# color-detection-opencv

Color detection with Python and OpenCV !

[![Watch the video](https://img.youtube.com/vi/aFNDh5k3SjU/0.jpg)](https://www.youtube.com/watch?v=aFNDh5k3SjU)
